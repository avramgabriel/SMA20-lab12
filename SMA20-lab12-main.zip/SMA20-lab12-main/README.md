# SMA20-lab12
SMA 2020 - Laborator 12
